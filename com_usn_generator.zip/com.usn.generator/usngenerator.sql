
CREATE TABLE admins (
username  VARCHAR(20) NOT NULL PRIMARY KEY,
password VARCHAR(200) NOT NULL
)

CREATE TABLE data (
sequence  VARCHAR(20) NOT NULL PRIMARY KEY,
date VARCHAR(50) NOT NULL,
purpose VARCHAR(100) NOT NULL,
username  VARCHAR(20) NOT NULL,
FOREIGN KEY (username) REFERENCES admins(username)
)
