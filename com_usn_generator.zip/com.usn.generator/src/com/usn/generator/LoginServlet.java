package com.usn.generator;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String username = request.getParameter("username");
        String password = request.getParameter("password");
 
        ///Insert Admin User
        /*String hashed = BCrypt.hashpw(password, BCrypt.gensalt());
        
        System.out.println("hashed:"+hashed);
        
        if (BCrypt.checkpw(password, hashed))
        	System.out.println("It matches");
        else
        	System.out.println("It does not match");
        
        DBInsertAdmin insertAdmin = new DBInsertAdmin(username,hashed);
        
        HttpSession session = request.getSession();

        session.setAttribute("User", username);

        response.sendRedirect("welcome.jsp");*/

        
        if(username == null || username.equals("") || password == null || password.equals("")){
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.html");
            PrintWriter out= response.getWriter();
            out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Lozinka i korisnicko ime su obavezna polja.\";   }</script>");
            rd.include(request, response);
        }else{

        	DBLogin loginAdmin = new DBLogin(username);
	
        	if(!loginAdmin.getProblemStatus()){

            if(loginAdmin.getUserExistsStatus() && BCrypt.checkpw(password, loginAdmin.getUserEncPass())){

                HttpSession session = request.getSession();

                session.setAttribute("User", username);
 
                response.sendRedirect("welcome.jsp");
            }else{
            	
            	
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.html");
                PrintWriter out= response.getWriter();
                out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Korisnicko ime ili lozinka su neispravni.\";   }</script>");
                rd.include(request, response);
            }
        	}else{
            	
            	
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/login.html");
                PrintWriter out= response.getWriter();

                out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Neuspjesno spajanje s bazom podataka.\";   }</script>");
                rd.include(request, response);
            }
        }
         
	}

}
