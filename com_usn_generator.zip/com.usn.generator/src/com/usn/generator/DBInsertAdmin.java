package com.usn.generator;

import java.sql.*;


public class DBInsertAdmin {

	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost/usngenerator";

	   static final String USER = "root";
	   static final String PASS = "password";
	   boolean redirect=false;
	   boolean problem=false;

	public DBInsertAdmin(String username,String hashed) {
	   Connection conn = null;
	   Statement stmt = null;
	   


	   try {
	      Class.forName("com.mysql.jdbc.Driver");

	      conn = DriverManager.getConnection(DB_URL,USER,PASS);

	      PreparedStatement ps = null;

	      String cmd = "INSERT INTO admins(username, password) " + "VALUES ('"+username+"', '"+hashed+"')";

			ps = conn.prepareStatement(cmd);
			
			ps.execute();
			
			redirect=true;
			

			} catch(SQLException se){
			     
				problem=true;
			      se.printStackTrace();
			   }catch(Exception e){
			      
				   problem=true;
			      e.printStackTrace();
			   }finally{
			      
			      try{
			         if(stmt!=null){
			        	 stmt.close();
			         }
			            
			      }catch(SQLException se2){
			    	  problem=true;
			      }
			      
			      try{
			         if(conn!=null){
			        	 conn.close();
			         }
			        	 
			            
			      }catch(SQLException se){
			    	  problem=true;
			         se.printStackTrace();
			      }
			   }

	
	}
	   
	   public boolean getProblemStatus(){
		   return this.problem;
	   }
	   public boolean getRedirectStatus(){
		   return this.redirect;
	   }



}
