package com.usn.generator;

import java.sql.*;
import java.util.ArrayList;

import java.util.List;

public class DBGetData {
	
	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost/usngenerator";

	   static final String USER = "root";
	   static final String PASS = "password";
	   
		List<String> name = new ArrayList<String>();
		List<String> date = new ArrayList<String>();
		List<String> pur = new ArrayList<String>();
		List<String> numseq = new ArrayList<String>();
	   
	   public DBGetData() {
	   Connection conn = null;
	   Statement stmt = null;
	   

	   

	   try {

	      Class.forName("com.mysql.jdbc.Driver");

	      conn = DriverManager.getConnection(DB_URL,USER,PASS);

	      PreparedStatement ps = null;
			ResultSet rs = null;
			String cmd = "SELECT * FROM data;";

				
			ps = conn.prepareStatement(cmd);
			
			rs = ps.executeQuery();

			while (rs.next()) {
				name.add(rs.getString("username"));
				date.add(rs.getString("date"));
				pur.add(rs.getString("purpose"));
				numseq.add(rs.getString("sequence"));
			} 

			} catch(SQLException se){

			      se.printStackTrace();
			   }catch(Exception e){

			      e.printStackTrace();
			   }finally{

			      try{
			         if(stmt!=null){
			        	 stmt.close();
			         }
			           
			      }catch(SQLException se2){
			      }
			      try{
			         if(conn!=null){
			        	 conn.close();
			         }
			           
			      }catch(SQLException se){
			         se.printStackTrace();
			      }
			   }
	}
	   
		public List<String> getAllUsername(){
			
			List<String> allUsername = new ArrayList<String>();
			
			allUsername=this.name;		
			
			return allUsername;
		}
		public List<String> getAllDate(){
			
			List<String> allDate = new ArrayList<String>();
			
			allDate=this.date;		
			
			return allDate;
		}
		public List<String> getAllPurpose(){
			
			List<String> allPurpose = new ArrayList<String>();
			
			allPurpose=this.pur;		
			
			return allPurpose;
		}
		public List<String> getAllSequence(){
			
			List<String> allSequence = new ArrayList<String>();
			
			allSequence=this.numseq;		
			
			return allSequence;
		}
}
