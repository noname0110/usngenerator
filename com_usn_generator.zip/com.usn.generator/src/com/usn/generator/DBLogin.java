package com.usn.generator;

import java.sql.*;

public class DBLogin {

	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost/usngenerator";

	   static final String USER = "root";
	   static final String PASS = "password";
	   boolean userexist=false;
	   boolean problem=false;
	   String dbpass = null;



	public DBLogin(String username) {
	   Connection conn = null;
	   Statement stmt = null;
	   


	   try {
	      Class.forName("com.mysql.jdbc.Driver");

	      conn = DriverManager.getConnection(DB_URL,USER,PASS);
	      PreparedStatement ps = null;	
	      ResultSet rs = null;	
	      boolean exist = false;
			
	      String cmd = "select password from admins where username='"+username+"' limit 1;";
	
		
	      ps = conn.prepareStatement(cmd);
	      rs = ps.executeQuery();
	      exist = rs.next();
			
	      if(exist){
				userexist=true;
				dbpass = rs.getString("password");
	      }	
	   } catch(SQLException se){
		   problem=true;      
		   se.printStackTrace();
			   
	   }catch(Exception e){
		   problem=true;		      
		   e.printStackTrace();   
	   }finally{
		   try{

			   if(stmt!=null)
				   stmt.close();
			    
		   }catch(SQLException se2){

			   problem=true;
		   }
			      
			      
		   try{
			         
			   if(conn!=null){
				   conn.close();
			   }
				   
			      
		   }catch(SQLException se){
			    	  
			   problem=true;    
			   se.printStackTrace();      
		   }	   
	   }

	}
	   
	   
	public boolean getProblemStatus(){
		   
		return this.problem;
		}
	   
	public boolean getUserExistsStatus(){
		   
		return this.userexist;
		}
	   
	public String getUserEncPass(){
		   
		return this.dbpass; 
	}


}
