package com.usn.generator;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class NewSeqServlet
 */
@WebServlet("/NewSeqServlet")
public class NewSeqServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewSeqServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String sequence = request.getParameter("hiddseq");
        String user = request.getParameter("hiddusername");
        String purpose = request.getParameter("purpose");
        String time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

        Calendar calendar = GregorianCalendar.getInstance(); 
        int currMinute=calendar.get(Calendar.MINUTE);  
        String strCurrMin= Integer.toString(currMinute); 
    
        
        HttpSession session = request.getSession();
        String usr = session.getAttribute("User").toString();
        
        //System.out.println("Sequence:"+sequence+" User:"+user+"=="+usr+" Purpose:"+purpose+" Time:"+time);
        
        if(purpose.length()<1){
        	
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/new.jsp");
            PrintWriter out= response.getWriter();
            out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Opis mora biti minimalno duljine jednog znaka.\";   }</script>");
            rd.include(request, response);
        	
        }else if(!usr.equals(user)){
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/new.jsp");
            PrintWriter out= response.getWriter();
            out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Greska, krivi korisnik.\";   }</script>");
            rd.include(request, response);
        }else if(!strCurrMin.equals(sequence)){
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/new.jsp");
            PrintWriter out= response.getWriter();
            out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Sekvenca se promjenila.\";   }</script>");
            rd.include(request, response);
        }
        
        else if(usr.equals(user)){
        	
        	//System.out.println("DB connection");
        	
        	DBInsertData insertData =new DBInsertData(sequence,time,purpose,user);
        	
        	//System.out.println("getProblemStatus"+insertData.getProblemStatus());
        	//System.out.println("getRedirectStatus"+insertData.getRedirectStatus());
        	
        	if (insertData.getRedirectStatus()){
        		response.sendRedirect("/com.usn.generator/welcome.jsp");
        	}else if(insertData.getProblemStatus()){
        		System.out.println(" SQLIntegrityConstraintViolationException");
		    	RequestDispatcher rd = getServletContext().getRequestDispatcher("/new.jsp");
	            PrintWriter out= response.getWriter();
	            out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Sekvenca vec postoji..\";   }</script>");
	            rd.include(request, response);
        		
        	}else{
        		System.out.println(" SQLIntegrityConstraintViolationException");
		    	RequestDispatcher rd = getServletContext().getRequestDispatcher("/new.jsp");
	            PrintWriter out= response.getWriter();
	            out.println("<script>window.onload = function() { var div = document.getElementById('errmsg').innerHTML = \"Problem pri unosu u bazu podataka.\";   }</script>");
	            rd.include(request, response);
        		
        	}
        }
 
 
	}

}
