

var $rows = $("tr[colspan=333]");
//var $rowss = $rows.next();
$("#searchinput").keypress(function(e) {

	
	if (e.which == 13){

    var val = $.trim(this.value);

    var nVal = val.length;
    
    if (val === ""){
    	
        $rows.slice(0, 10).show();
       // $rowss.show();
    
    }
    else if (nVal>=3){
    	
        $rows.hide();
        //$rowss.hide();
        $rows.has("td:contains(" + val + ")").show();
        //$rows.has("td:contains(" + val + ")").next().show();
    }
    
}

});

$(' .commButton').click(function(){
	
	
	var searchstring = $('#searchinput');
	searchstring.focus();
	
	//alert("searchfield=  " + searchstring.val());
	
	var val = searchstring.val()
	
    var vall = $.trim(val);

    var nVal = vall.length;
    
    if (vall === ""){
    	
    	$rows.slice(0, 10).show();
       // $rowss.show();
    
    }
    else if (nVal>=3){
    	
        $rows.hide();
        //$rowss.hide();
        $rows.has("td:contains(" + vall + ")").show();
        //$rows.has("td:contains(" + val + ")").next().show();
    }
	
});


/*$(function() {
    $("td[colspan=3]").find("p").hide();
    
    $("tr[colspan=333]").click(function(event) {
        event.stopPropagation();
        var $target = $(event.target);
        if ( $target.closest("td").attr("colspan") > 1 ) {
            $target.slideUp();
            $target.closest("tr").prev().find("td:first").html("+");
        } else {
            $target.closest("tr").next().find("p").slideToggle();
            if ($target.closest("tr").find("td:first").html() == "+")
                $target.closest("tr").find("td:first").html("-");
            else
                $target.closest("tr").find("td:first").html("+");                
        }                    
    });
});*/
$('.getSeqData').click(function(){

    var seq = $(this).closest( "td" ).text();
    var usr = $(this).closest( "td" ).next().text();
    var con = $(this).closest( "td" ).next().next().next().text();
    var date = $(this).closest( "td" ).next().next().text();
    
    //alert(seq+" "+usr+" "+con+" "+date);
    
				var table = 
				    '<div class="modal-dialog">' + 

				      '<div class="modal-content">' + 
				       ' <div class="modal-header">' + 
				          '<button type="button" class="close" data-dismiss="modal">&times;</button>' + 
				         ' <h4 class="modal-title">Document details</h4>' + 
				        '</div>' + 
				        '<div class="modal-body">' + 
				      
				        
				'<table class="modaltablee">' +
				'<thead>' +
               '<th>Sequence is:</th>' +
            	'<th>By user:</th>' +
            	'<th>Date created:</th>' +
            	'<th>Purpose...:</th>' +
            '</thead>' +
            '<tbody>' +
            
				  '<tr><td>'+ seq+
				  '</td></tr><tr><td>'+usr+
				  '</td></tr><tr><td>'+con+
				  '</td></tr><tr><td>'+date+
				  '</td></tr>'+

				 ' </tbody>' +
				'</table>' + 
				'</div>' + 

				        '<div class="modal-footer">' + 
				          '<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>' + 
				       ' </div>' + 
				      '</div>' + 
				      
				    '</div>';

					document.getElementById('myModal').innerHTML = table;





});
	
	$('.getUserData').click(function(){

	    var seq = $(this).closest( "td" ).prev().prev().prev().prev().text();
	    var usr = $(this).closest( "td" ).prev().prev().prev().text();
	    var con = $(this).closest( "td" ).prev().prev().text();
	    var date = $(this).closest( "td" ).prev().text();
	    
	    //alert(seq+" "+usr+" "+con+" "+date);
	    
					var table = 
					    '<div class="modal-dialog">' + 

					      '<div class="modal-content">' + 
					       ' <div class="modal-header">' + 
					          '<button type="button" class="close" data-dismiss="modal">&times;</button>' + 
					         ' <h4 class="modal-title">Document details</h4>' + 
					        '</div>' + 
					        '<div class="modal-body">' + 
					      
					        
					'<table class="modaltablee">' +
					'<thead>' +
                   '<th>Sequence is:</th>' +
                	'<th>By user:</th>' +
                	'<th>Date created:</th>' +
                	'<th>Purpose...:</th>' +
                '</thead>' +
                '<tbody>' +
                
					  '<tr><td>'+ seq+
					  '</td></tr><tr><td>'+usr+
					  '</td></tr><tr><td>'+con+
					  '</td></tr><tr><td>'+date+
					  '</td></tr>'+
 
					 ' </tbody>' +
					'</table>' + 
					'</div>' + 

					        '<div class="modal-footer">' + 
					          '<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>' + 
					       ' </div>' + 
					      '</div>' + 
					      
					    '</div>';

						document.getElementById('myModal').innerHTML = table;

	
	
	
	
	});	
	
	$('.primary').click(function(){

	    var seq = $(this).closest( "td" ).prev().prev().prev().prev().text();
	    var usr = $(this).closest( "td" ).prev().prev().prev().text();
	    var con = $(this).closest( "td" ).prev().prev().text();
	    var date = $(this).closest( "td" ).prev().text();
	    
	    //alert(seq+" "+usr+" "+con+" "+date);
	    
					var table = 
					    '<div class="modal-dialog">' + 

					      '<div class="modal-content">' + 
					       ' <div class="modal-header">' + 
					          '<button type="button" class="close" data-dismiss="modal">&times;</button>' + 
					         ' <h4 class="modal-title">Document details</h4>' + 
					        '</div>' + 
					        '<div class="modal-body">' + 
					      
					        
					'<table class="modaltablee">' +
					'<thead>' +
                   '<th>Sequence is:</th>' +
                	'<th>By user:</th>' +
                	'<th>Date created:</th>' +
                	'<th>Purpose...:</th>' +
                '</thead>' +
                '<tbody>' +
                
					  '<tr><td>'+ seq+
					  '</td></tr><tr><td>'+usr+
					  '</td></tr><tr><td>'+con+
					  '</td></tr><tr><td>'+date+
					  '</td></tr>'+
 
					 ' </tbody>' +
					'</table>' + 
					'</div>' + 

					        '<div class="modal-footer">' + 
					          '<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>' + 
					       ' </div>' + 
					      '</div>' + 
					      
					    '</div>';

						document.getElementById('myModal').innerHTML = table;

	
	
	
	
	});	

